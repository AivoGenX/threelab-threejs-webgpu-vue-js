# @recast-navigation/generators

This package contains "Preset" NavMesh generators for @recast-navigation/core that make getting started easy.

These can also be used as a basis for your own generator.

Please refer to the [main package's README](https://github.com/isaac-mason/recast-navigation-js/tree/main/packages/recast-navigation/README.md) for usage information.
