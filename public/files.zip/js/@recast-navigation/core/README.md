# @recast-navigation/core

This package contains the the core functionality for `recast-navigation`. Please refer to the [main package's README](https://github.com/isaac-mason/recast-navigation-js/tree/main/packages/recast-navigation/README.md) for usage information.
