export const WGS84_RADIUS;
export const WGS84_FLATTENING;
export const WGS84_HEIGHT;
