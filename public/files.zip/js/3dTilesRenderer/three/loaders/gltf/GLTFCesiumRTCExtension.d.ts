export class GLTFCesiumRTCExtension{

	name: 'CESIUM_RTC';

}
