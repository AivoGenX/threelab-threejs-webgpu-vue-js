import { Ellipsoid } from './Ellipsoid';

export const WGS84_ELLIPSOID : Ellipsoid;
